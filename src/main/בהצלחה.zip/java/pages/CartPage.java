package pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class CartPage extends Base {
    private By emailField = By.name("email");
    private By firstNameField = By.name("firstName");
    private By lastNameField = By.name("lastName");
    private By addressField = By.name("address1");
    private By apartmentField = By.name("address2");
    private By cityField = By.name("city");
    private By zipField = By.name("zip");
    private By countryField = By.name("countryCode");
    private By phoneField = By.name("phone");
    private By submitButton = By.cssSelector("#checkout-pay-button");
    private By errorField = By.cssSelector(".field-error");

    private By cartRow = By.cssSelector("div._6zbcq51n ._19gi7yt0"); // selector לכל שורת מוצר בסל
    private By priceInRow = By.cssSelector("[class=\"_197l2oft _1fragemnn _1fragemme _1fragem28 _1fragemlj Byb5s\"] [class=\"_19gi7yt0 _19gi7ytw _19gi7ytv _1fragemnu notranslate\"]"); // selector למחיר
    private By quantityInRow = By.cssSelector("div._6zbcq51n span:nth-child(2)");
    private By totalSumElement = By.cssSelector("strong._19gi7yt0._19gi7yt10._19gi7ytz._1fragemnw");
    private By shippingCheckbox = By.cssSelector("#delivery_strategies-SHIPPING");
    private By shopingCartButton = By.cssSelector(".header__nav-icon.icon.icon-cart");
    private By postelPlace=By.cssSelector("#AutocompleteSingleAddressField0");
    private By pickOption = By.cssSelector("#delivery_strategies-PICK_UP");
    private By changeLocation = By.cssSelector("#Form0 > div.km09ry1._1fragemlj > div:nth-child(4) > div > section > div > div._1ip0g651._1ip0g650._1fragemlj._1fragem4b._1fragem64._1fragem2s > section:nth-child(2) > div > div > div._1mrl40q0._1fragemlj._1fragem4o._1fragem6h._1fragemma._1fragemmf._1fragem2s._1fragemm3._1fragem78._1fragemoh._16s97g7f._16s97g7i._16s97g7p._16s97g71j._16s97g71m._16s97g71t > button");
    private  By findStores=By.cssSelector("[class=\"_1m2hr9ge _1m2hr9gd _1fragemsq _1fragemlj _1fragemnk _1fragem2i _1fragems4 _1fragemsg _1fragemsl _1fragemsa _1m2hr9g16 _1m2hr9g13 _1fragemop _1fragemon _1fragemor _1fragemol _1fragempl _1fragemph _1fragempp _1fragempd _1fragemb4 _1fragemaf _1fragembt _1fragem9q _1fragemsa _1m2hr9g1q _1m2hr9g1o _1m2hr9g10 _1m2hr9gx _1m2hr9g29 _1m2hr9g28 _1fragems0 _1m2hr9g1b _1m2hr9g19 _1fragems5 _1m2hr9g25\"]");
    public CartPage(WebDriver driver, WebDriverWait wait) {
        super(driver, wait);
    }





    public void verifyPaymentButtonIsDisabledWhenCartIsEmpty() {

        click(shopingCartButton);
        // חפש את כפתור התשלום


        if (!isDisplayed(shopingCartButton)) {
            throw new AssertionError("Expected the payment button to be disabled when the cart is empty.");
        }
    }

    public double calculateTotalInCart() {
        List<WebElement> priceElements = findElements(priceInRow);
        List<WebElement> quantityElements = findElements(quantityInRow);

        double total = 0.0;
        System.out.println("מספר מחירים: " + priceElements.size());
        System.out.println("מספר כמויות: " + quantityElements.size());
        // Ensure both lists have the same size
        if (priceElements.size() != quantityElements.size()) {
            System.out.println("שגיאה: מספר האלמנטים של מחירים וכמויות לא תואם.");
            return total; // Return 0 if there is a mismatch
        }

        // Loop through each price and corresponding quantity element
        for (int i = 0; i < priceElements.size(); i++) {
            WebElement priceElement = priceElements.get(i);
            WebElement quantityElement = quantityElements.get(i);

            // Get the price and quantity values
            String priceText = priceElement.getText().replace("₪", "").trim(); // Remove ₪ sign
            String quantityText = quantityElement.getText().trim(); // Get the quantity as text

            // Convert to double
            double price = Double.parseDouble(priceText);
            int quantity = Integer.parseInt(quantityText);

            // Calculate total for this item
            total += price * quantity;
        }

        return total;
    }

    public void waitForCartToLoad() {
        waitUntilElementLocated(totalSumElement);
        waitUntilElementLocated(cartRow);
    }

    public double getTotalSumDisplayed() {
        String totalText = findElement(totalSumElement).getText().trim().split("\\.")[0]; // קבל את הטקסט של הסכום הכולל
        return parsePrice(totalText.replaceAll("[^0-9]", "")); // המרה לערך מספרי
    }

    private double parsePrice(String text) {
        try {
            return Double.parseDouble(text.replaceAll("[^0-9.]", "")); // הסרת תווים לא מספריים
        } catch (NumberFormatException e) {
            return 0; // החזר 0 במקרה של שגיאה
        }
    }
    public void validateAllFormFields() {

        // בדיקות שדות
        validateInvalidEmail();

        validateInvalidFirstName();

        validateInvalidLastName();
        validateInvalidAddress();
        validateCountryNotSelected();
        validateInvalidPhone();
        validateValidInput();
    }

    public boolean verifyTotalWithShipping(double totalSum, double shippingFee) {
        double displayedTotal = getTotalSumDisplayed();
        System.out.println(displayedTotal );
        System.out.println(totalSum );

        if (totalSum < 300) {
            if (findElement(shippingCheckbox).isSelected()) {
                return displayedTotal == totalSum + shippingFee; // חישוב כולל עם דמי משלוח
            } else {
                return displayedTotal == totalSum; // חישוב כולל בלי דמי משלוח
            }
        }
        return true; // אם הסכום הכולל הוא מעל 300, אין דמי משלוח
    }
    public void getPickOption() {
        // בחר באופציית Pick
        click(pickOption);
    }

    public void enterPostalCode(String postalCode) {
       click(changeLocation);
        // הזנת מיקוד
       type(postalCode,postelPlace);


    }
    public boolean verifyPaymentButtonEnabled(){
        // בדיקה שהכפתור מופעל לאחר הזנת המיקוד
    return     isDisplayed(findStores);
    }

    //מכאןןןןןןןןןןןןןןןןןןןן
    private void validateInvalidEmail() {
        System.out.println("Typing invalid email in the email field.");
        type("invalidemail", emailField);

        System.out.println("Clicking on the submit button.");
        click(submitButton);

        System.out.println("Looking for the error message for email.");
        findElement(By.cssSelector("#error-for-email"));

        System.out.println("Clearing the email field.");
        clearField(emailField);
    }


    private void validateInvalidFirstName() {
        type("12345", firstNameField);
        click(submitButton);
        Assert.assertTrue(getText(errorField).contains("שם פרטי לא תקין"));
        clearField(firstNameField);
    }

    private void validateInvalidLastName() {
        type("!@#$%", lastNameField);
        click(submitButton);
        Assert.assertTrue(getText(errorField).contains("שם משפחה לא תקין"));
        clearField(lastNameField);
    }

    private void validateInvalidAddress() {
        type("!@#$%^", addressField);
        click(submitButton);
        Assert.assertTrue(getText(errorField).contains("כתובת לא תקינה"));
        clearField(addressField);
    }

    private void validateCountryNotSelected() {
        new Select(findElement(countryField)).selectByVisibleText("");
        click(submitButton);
        Assert.assertTrue(getText(errorField).contains("בחר מדינה"));
    }

    private void validateInvalidPhone() {
        type("abc123", phoneField);
        click(submitButton);
        Assert.assertTrue(getText(errorField).contains("מספר טלפון לא תקין"));
        clearField(phoneField);
    }

    private void validateValidInput() {
        type("validemail@example.com", emailField);
        type("יוסי", firstNameField);
        type("כהן", lastNameField);
        type("רחוב הדקל 3", addressField);
        type("12", apartmentField);
        type("תל אביב", cityField);
        type("1234567", zipField);
        new Select(findElement(countryField)).selectByVisibleText("ישראל");
        type("0501234567", phoneField);

        // וודא שאין הודעת שגיאה
        click(submitButton);
        Assert.assertTrue(isDisplayed(errorField) == false);
    }
    private void clearField(By locator) {
        findElement(locator).clear();
    }
}
