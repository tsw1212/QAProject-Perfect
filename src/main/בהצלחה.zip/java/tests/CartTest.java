package tests;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.CartPage;
import pages.HomePage;

import java.time.Duration;

public class CartTest {
    private WebDriver driver;
    private WebDriverWait wait;
    private CartPage cartPage;
    private HomePage homePage;


    @Before
    public void setup() {
        driver = new CartPage(driver, wait).chromeDriverConnection();
        wait = new WebDriverWait(driver, Duration.ofSeconds(30)); // זמן ההמתנה הכללי
        cartPage = new CartPage(driver, wait);
        homePage = new HomePage(driver, wait);
        cartPage.visit("https://perfectaccessories.co.il/");
    }

    @Test
    public void shouldAddItemsToCartAndVerifyTotal() {
        homePage.addProduct1ToCart(); // הוספת  פריט לעגלה

    //  homePage.addProduct2ToCart(); // הוספת  פריט לעגלה

        homePage.proceedToPayment(); // מעבר לעמוד התשלום

        double totalSum = cartPage.calculateTotalInCart();
        double shippingFee = 30;

        cartPage.waitForCartToLoad(); // המתנה לטעינת העגלה באופן דינמי
        boolean isTotalCorrect = cartPage.verifyTotalWithShipping(totalSum, shippingFee);

        assert isTotalCorrect : "The total amount displayed does not match the expected total with shipping.";
    }

    @Test
    public void shouldNotAllowPaymentWhenCartIsEmpty() {


        // בודק שכאשר העגלה ריקה, לא ניתן לבצע תשלום
        cartPage.verifyPaymentButtonIsDisabledWhenCartIsEmpty();
    }
    //שינוי קוד ביום האחרון להגשה
//    @Test
//    public void shouldAllowEnterPostalCode() {
//
//        homePage.addProductToCart(); // הוספת  פריט לעגלה
//        homePage.proceedToPayment(); // מעבר לעמוד התשלום
//
//
//        // הזנת מיקוד
//        cartPage.getPickOption(); // תוסיף מתודה שתבחר באופציה של PICK UP
//        cartPage.enterPostalCode("9931915");
//
//        // בדיקה שהכפתור מופעל לאחר הזנת המיקוד
//       boolean  verifyPaymentButtonEnabled=  cartPage.verifyPaymentButtonEnabled();
//        assert verifyPaymentButtonEnabled : "The button for finding the stores is not available";
//    }
    @Test
    public void validateAllFormFields() {

        homePage.addProduct1ToCart(); // הוספת  פריט לעגלה
        homePage.proceedToPayment(); // מעבר לעמוד התשלום
        cartPage.validateAllFormFields();
    }

    @After
    public void endTest() {
        driver.quit();
    }
}
